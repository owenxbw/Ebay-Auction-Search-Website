drop table IF EXISTS Categorys;

drop table IF EXISTS Bider;

drop table IF EXISTS User;

drop table IF EXISTS Items;
