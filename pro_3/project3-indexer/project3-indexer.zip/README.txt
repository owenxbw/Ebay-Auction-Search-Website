

Indexes "ItemID", "Name" "Category" "Description" and "Content" are chosen.

In build.xml, I add commands to delete all indexes in /var/lib/lucene/ at 
the beginning to avoid errors when running the program muiltiple times.


To build and run the sample code, use the "run" ant target inside 
the directory with build.xml by typing "ant run".
