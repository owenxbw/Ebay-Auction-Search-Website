package edu.ucla.cs.cs144;



public class Lindex_path{
	public static final String lucene_path = "/var/lib/lucene/"; 
}