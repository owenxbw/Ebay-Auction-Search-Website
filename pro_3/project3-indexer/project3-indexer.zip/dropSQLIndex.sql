DROP INDEX g ON Item_loc;
DROP table Item_loc;
